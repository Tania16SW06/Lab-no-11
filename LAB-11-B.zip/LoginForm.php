<!DOCTYPE html>
<html>
<head>
	<title>Kashmala Sajjad</title>
</head>
<body>
	 <form name="LoginForm" method="POST" action="Cookies.php">
		<center>
		<h1>Login Form</h1>
		<p>Enter your name</p>
		<input type="text" name="first" placeholder="enter name" id="name" required="" />
		<p >Enter Password</p>
		<input type="Password" name="Password" placeholder="eg:16SW44" id="password" required="" />
		<br><input type="Submit" name="btn" placeholder="Submit" />
	    <p><input type="checkbox" name="chk"/>Remember me</p>
	    <a href="MAIL TO:Kashmalakhan544@yahoo.com">Forgot password?</a>
	</center>
	</form>
</body>
</html>
