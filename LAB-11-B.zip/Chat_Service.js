function ShowChat(){
document.getElementById("Sidra").style.visibility="visible";
}
function ShowChat2(){

	document.getElementById("Tania").style.visibility="visible";

}
function CloseChat(){

	document.getElementById("Sidra").style.visibility="hidden";

}
function CloseChat2(){

	document.getElementById("Tania").style.visibility="hidden";

}