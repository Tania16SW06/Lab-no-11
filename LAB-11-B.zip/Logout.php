<!DOCTYPE html>
<html>
<head>
	<?php
session_start();
	?>
<link rel="stylesheet" type="text/css" href="Chat_Service.css">
	<link href="https://fonts.googleapis.com/css?family=Courgette|Monoton" rel="stylesheet">
	<script type="text/javascript" src="Chat_Service.js"></script>

</head>
<body style="padding: 0px" bgcolor="#ffffcc">
	<header >
	<center>	<h1 id="clipped-title1" name="H1">CHATTERBOX</h1></center>
	</header>
<div class="First_div" style="margin-top: 20px">
	<article style="display: flex;">
				<img src="https://media5.picsearch.com/is?_cScHYlNFN2kapX08Woav7FFInwL6Mv55Xsvkw0yUSc&height=312" ></img>
	         	<p>Kashmala Khan</p>
	</article>
	<article style="display:flex;"  onclick="ShowChat();" id="a1">
				<img src="https://www.trickscity.com/wp-content/uploads/2017/09/19120328_262626134217521_1712231095287676928_n.jpg.jpg" ></img>
	         	<p>Sidra Khanzada</p>
	</article>
	<article style="display: flex;" onclick="ShowChat2();">
				<img src="https://www.trickscity.com/wp-content/uploads/2017/08/17126510_105379763326591_3977110299864989696_n.jpg.jpg" ></img>
	         	<p>Tania Khan</p>
	</article>
	
	
</div>
<div class="Second_div" >
	<div class="First_Child_Div" id="Tania"  style="position: relative">
		<div style="background: gray;display:flex;height:25px;" >
					    <p>Tania</p>
			<img src="https://image.flaticon.com/icons/png/128/484/484613.png" style="height: 17px;width: 17px;border-radius: 50%;margin-right: 10px;margin-left: 95px">
			<img src="https://img.icons8.com/material-outlined/1600/video-call.png" style="height: 20px;width: 20px;border-radius: 50%;">
			<img src="https://img.icons8.com/ios/2x/cancel.png" style="height: 20px;width: 20px;border-radius: 50%;margin-left: 10px" onclick="CloseChat2();">
		</div>
		
	<div style="background:#013243;color:white;float: left;border-radius:5px;size:10px;margin-top: 8px">Hi I'm Smith</div>
<div style="margin-bottom:0;display: flex;position: absolute;bottom: 0px;left: 0px;width: 100%">
		<input type="text" placeholder="Enter your text..">
		<input type="Submit" style="margin-left: -37px;border-radius: 6px;background:lightgray" value="Send" >
	</div></div>
	<div class="First_Child_Div" style="position: relative;left: 10px" id="Sidra">
		<div style="background: gray;display: flex;height:25px;">
		    <p>Sidra</p>
			<img src="https://image.flaticon.com/icons/png/128/484/484613.png" style="height: 17px;width: 17px;border-radius: 50%;margin-right: 10px;margin-left:95px">
			<img src="https://img.icons8.com/material-outlined/1600/video-call.png" style="height: 20px;width: 20px;border-radius: 50%;">
			<img src="https://img.icons8.com/ios/2x/cancel.png" style="height: 20px;width: 20px;border-radius: 50%;margin-left: 10px;" onclick="CloseChat();">
		</div>
		
	<div style="background:#013243;color:white;float: left;border-radius:5px;size:10px;margin-top:8px;">Hi I'm Sidra</div>
	<br><div style="background:lightgray;color:black;float: right;border-radius:5px;size:10px;">Hellow </div>
	<br><div style="background:#013243;color:white;float: left;border-radius:5px;size:10px;">How are you?</div>
	<br><div style="background:lightgray;color:black;float: right;border-radius:5px;size:10px;">Fine</div>
	<br><div style="background:#013243;color:white;float: left;border-radius:5px;size:10px;">Hellow</div>
	
		
<div style="display: flex;position:absolute;bottom: 0px;left: 0px;width: 100%">
		<input type="text" placeholder="Enter your text..">
		<input type="Submit" style="margin-left: -37px;border-radius: 6px;background:lightgray;" value="Send" >
	</div>
</div></div>
<footer style="position: fixed;bottom: 0px;left: 0px;width: 100%"> 	
	<form method="POST" action="Destroy.php">
	<button style="height:25px;margin-left:1000px;margin-top:7px;border-radius:5px" name="signout" >Sign-me-out
	</button></form>
</footer>
</body>
</html>